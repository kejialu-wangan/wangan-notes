import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.asymmetric import rsa, padding as asym_padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

print("=" * 50)
print("步骤 3: AES 加解密实践")
print("=" * 50)

# 1. 准备明文和密钥
plaintext = b"This is a test message to show AES encryption. AAAABBBBCCCCDDDD"
key = os.urandom(16) # 生成 16 字节的随机密钥
iv = os.urandom(16)  # 生成 16 字节的初始化向量

# 对明文进行 PKCS7 填充
padder = padding.PKCS7(128).padder()
padded_plaintext = padder.update(plaintext) + padder.finalize()

# 2. AES-CBC 模式加密与解密
cipher_cbc = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
encryptor = cipher_cbc.encryptor()
ciphertext_cbc = encryptor.update(padded_plaintext) + encryptor.finalize()

print(f"\nCBC模式加密后的密文 (Hex): {ciphertext_cbc.hex()}")

decryptor = cipher_cbc.decryptor()
decrypted_padded = decryptor.update(ciphertext_cbc) + decryptor.finalize()
unpadder = padding.PKCS7(128).unpadder()
decrypted_plaintext = unpadder.update(decrypted_padded) + unpadder.finalize()
print(f"解密后的明文: {decrypted_plaintext}")

# 3. AES-ECB 模式加密 (用于对比)
cipher_ecb = Cipher(algorithms.AES(key), modes.ECB(), backend=default_backend())
encryptor_ecb = cipher_ecb.encryptor()
ciphertext_ecb = encryptor_ecb.update(padded_plaintext) + encryptor_ecb.finalize()
print(f"ECB模式加密后的密文 (Hex): {ciphertext_ecb.hex()}")
print(f"\n【观察】ECB模式下密文有重复规律，CBC模式下密文具有完全的随机性。")


print("\n" + "=" * 50)
print("步骤 4: RSA 加解密与数字签名")
print("=" * 50)

# 1. 生成 2048 位的 RSA 密钥对
private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())
public_key = private_key.public_key()
print("\n已成功生成 2048 位 RSA 密钥对。")

message = b"This is a top secret message for RSA test."
print(f"原始消息: {message}")

# 2. 公钥加密，私钥解密
ciphertext = public_key.encrypt(message, asym_padding.OAEP(mgf=asym_padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
decrypted_message = private_key.decrypt(ciphertext, asym_padding.OAEP(mgf=asym_padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
print(f"RSA加密后的密文 (Hex): {ciphertext.hex()}")
print(f"解密后的消息: {decrypted_message}")
print(f"加解密验证是否成功: {message == decrypted_message}")

# 3. 私钥签名，公钥验签
signature = private_key.sign(message, asym_padding.PSS(mgf=asym_padding.MGF1(algorithm=hashes.SHA256()), salt_length=asym_padding.PSS.MAX_LENGTH), hashes.SHA256())
print(f"\n生成的数字签名 (Hex): {signature.hex()[:60]}...")

try:
    public_key.verify(signature, message, asym_padding.PSS(mgf=asym_padding.MGF1(algorithm=hashes.SHA256()), salt_length=asym_padding.PSS.MAX_LENGTH), hashes.SHA256())
    print("验签结果: 签名有效！消息未被篡改。")
except Exception as e:
    print(f"验签失败: {e}")
