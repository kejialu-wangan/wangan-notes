# 凯撒密码 加密、解密、暴力破解
def caesar_encrypt(plaintext, shift):
    ciphertext = ""
    for char in plaintext:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            ciphertext += chr( (ord(char) - base + shift) % 26 + base )
        else:
            ciphertext += char
    return ciphertext

def caesar_decrypt(ciphertext, shift):
    # 解密等价于反向移位
    return caesar_encrypt(ciphertext, -shift)

def brute_force_crack(ciphertext):
    print("===== 暴力破解全部25种移位结果 =====")
    for s in range(1,26):
        res = caesar_decrypt(ciphertext, s)
        print(f"移位{s:2d}: {res}")

if __name__ == "__main__":
    # ========= 实验示例 =========
    plain = "HELLO GOOD"
    shift_key = 3
    cipher = caesar_encrypt(plain, shift_key)
    
    print(f"明文：{plain}")
    print(f"密钥移位：{shift_key}")
    print(f"密文：{cipher}")
    print(f"解密结果：{caesar_decrypt(cipher,shift_key)}")
    print("\n开始暴力破解：")
    brute_force_crack(cipher)
