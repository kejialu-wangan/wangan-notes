from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
import os

# 1. 生成随机密钥和IV
key = os.urandom(16)  # 128位密钥（16字节）
iv = os.urandom(16)   # 16字节的IV（CBC模式必需）

# 2. 明文（需填充为16字节的倍数）
plaintext = b"Hello, AES CBC Mode! This is a test message for encryption and decryption."

# 3. 填充明文（PKCS7，块大小128位=16字节）
padder = padding.PKCS7(128).padder()
padded_plaintext = padder.update(plaintext) + padder.finalize()

# 4. CBC模式加密
cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
encryptor = cipher.encryptor()
ciphertext = encryptor.update(padded_plaintext) + encryptor.finalize()

print("--- CBC模式加密结果 ---")
print(f"原始明文：{plaintext.decode('utf-8')}")
print(f"密钥（Hex）：{key.hex()}")
print(f"IV（Hex）：{iv.hex()}")
print(f"填充后明文（Hex）：{padded_plaintext.hex()}")
print(f"密文（Hex）：{ciphertext.hex()}")

# 5. CBC模式解密
decryptor = cipher.decryptor()
decrypted_padded = decryptor.update(ciphertext) + decryptor.finalize()

# 6. 移除填充
unpadder = padding.PKCS7(128).unpadder()
decrypted_text = unpadder.update(decrypted_padded) + unpadder.finalize()
print("\n--- CBC模式解密结果 ---")
print(f"解密后明文：{decrypted_text.decode('utf-8')}")
print(f"解密成功：{decrypted_text == plaintext}")
