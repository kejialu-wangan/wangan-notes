import hashlib
s
def get_file_hash(file_path):
    # 计算文件MD5、SHA256
    md5_obj = hashlib.md5()
    sha256_obj = hashlib.sha256()
    with open(file_path, 'rb') as f:
        while chunk := f.read(4096):
            md5_obj.update(chunk)
            sha256_obj.update(chunk)
    return md5_obj.hexdigest(), sha256_obj.hexdigest()

# 原始文件哈希
md5_ori, sha256_ori = get_file_hash("test.txt")
print("===== 修改前 =====")
print(f"MD5:     {md5_ori}")
print(f"SHA-256: {sha256_ori}")

# 修改文件1个字节：把末尾的字符改动1位
with open("test.txt", "rb") as f:
    data = bytearray(f.read())
if len(data) > 0:
    data[0] = data[0] ^ 0x01 # 只修改第一个字节，仅仅改动1bit
with open("test.txt", "wb") as f:
    f.write(data)

# 修改后哈希
md5_new, sha256_new = get_file_hash("test.txt")
print("\n===== 修改1字节后 =====")
print(f"MD5:     {md5_new}")
print(f"SHA-256: {sha256_new}")

print("\n✅结论：仅仅改动1字节，MD5和SHA256哈希值全部完全改变，哈希可以校验文件完整性")
