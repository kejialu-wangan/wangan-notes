# 构造包含重复块的明文（16 字节的倍数，且包含重复部分）
# "AAAAAAAAAAAAAAAA" 重复多次，确保有相同的明文块
plaintext_ecb = b"AAAAAAAAAAAAAAAA" * 4 + b"BBBBBBBBBBBBBBBB"  # 5 个块，前 4 个块相同

# 密钥（为了公平对比，ECB 和 CBC 可以用不同 IV，但密钥可以相同或不同，这里用相同密钥）
key_ecb = os.urandom(16)
iv_ecb = os.urandom(16) # ECB 不需要 IV，但 CBC 需要

# --- ECB 模式 ---
cipher_ecb = Cipher(algorithms.AES(key_ecb), modes.ECB(), backend=default_backend())
encryptor_ecb = cipher_ecb.encryptor()
ciphertext_ecb = encryptor_ecb.update(plaintext_ecb) + encryptor_ecb.finalize()

# --- CBC 模式 ---
cipher_cbc = Cipher(algorithms.AES(key_ecb), modes.CBC(iv_ecb), backend=default_backend())
encryptor_cbc = cipher_cbc.encryptor()
ciphertext_cbc = encryptor_cbc.update(plaintext_ecb) + encryptor_cbc.finalize()

print("\n--- ECB 与 CBC 密文对比 ---")
print(f"明文块: {plaintext_ecb.hex()}")
print(f"ECB 密文 (hex): {ciphertext_ecb.hex()}")
print(f"CBC 密文 (hex): {ciphertext_cbc.hex()}")

# 将密文按 16 字节（32 个 hex 字符）分段，观察重复块
def split_blocks(hex_str, block_size=32):
    return [hex_str[i:i+block_size] for i in range(0, len(hex_str), block_size)]

print("\nECB 密文块:")
for i, block in enumerate(split_blocks(ciphertext_ecb.hex())):
    print(f"  块 {i+1}: {block}")

print("\nCBC 密文块:")
for i, block in enumerate(split_blocks(ciphertext_cbc.hex())):
    print(f"  块 {i+1}: {block}")
